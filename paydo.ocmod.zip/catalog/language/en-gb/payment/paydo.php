<?php

$_['heading_title']    = 'Paydo';

$_['text_title']         = 'Paydo Payment Gateway';
$_['text_description']   = 'Secure online payment via Paydo.';
$_['text_payment_status'] = 'Payment Status: %s';

$_['button_pay']         = 'Pay Now';
$_['order_description']  = 'Payment for Order #%s';
