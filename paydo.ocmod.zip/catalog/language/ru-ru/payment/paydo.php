<?php

$_['text_title']         = 'Paydo Платежный Шлюз';
$_['text_description']   = 'Безопасная онлайн-оплата через Paydo.';
$_['text_payment_status'] = 'Статус платежа: %s';

$_['button_pay']         = 'Оплатить сейчас';
$_['order_description']  = 'Оплата заказа #%s';
