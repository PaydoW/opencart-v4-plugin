<?php

$_['text_title']         = 'Paydo Платіжний Шлюз';
$_['text_description']   = 'Безпечна онлайн-оплата через Paydo.';
$_['text_payment_status'] = 'Статус платежу: %s';

$_['button_pay']         = 'Оплатити зараз';
$_['order_description']  = 'Оплата замовлення #%s';
